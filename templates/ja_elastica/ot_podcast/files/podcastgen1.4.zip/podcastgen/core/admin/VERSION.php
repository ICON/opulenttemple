<?php
############################################################
# PODCAST GENERATOR
#
# Created by Alberto Betella
# http://podcastgen.sourceforge.net
# 
# This is Free Software released under the GNU/GPL License.
############################################################

### HERE IS DEFINED PODCASTGEN VERSION

$podcastgen_version = "1.4";

?>