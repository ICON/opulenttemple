// EN lang variables

tinyMCE.addToLang('visualchars',{
desc : 'Visual control characters on/off.'
});
